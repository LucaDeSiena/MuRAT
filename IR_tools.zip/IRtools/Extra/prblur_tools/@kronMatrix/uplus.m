function m = uplus(k)
%  kronMatrix/uplus
%
%     +k = k
%

m = k;
