function n = times(k, m)
%  kronMatrix .*
%

